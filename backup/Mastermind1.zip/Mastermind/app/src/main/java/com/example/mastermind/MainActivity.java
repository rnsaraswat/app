package com.example.mastermind;

import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {


    EditText etGuess;

    TextView txtResult;
    TextView txtHistory;

    private int[] guessColors;
    private int exactMatches;
    private int partialMatches;

    private RecyclerView historyRecycler;

    private ArrayList<HistoryItem> historyList;

    private HistoryAdapter historyAdapter;

    private static final int RED = 1;
    private static final int BLUE = 2;
    private static final int GREEN = 3;
    private static final int YELLOW = 4;
    private static final int PURPLE = 5;
    private static final int ORANGE = 6;
    private static final int CYAN = 7;
    private static final int PINK = 8;
    private static final int BROWN = 9;
    private static final int GRAY = 10;

    private Spinner spinnerDifficulty;
    private Switch switchDuplicate;
    private TextView txtAttempts;
    private TextView txtScore;

    private Button btnCheck;
    private Button btnUndo;
    private Button btnRestart;

    private GridLayout feedbackGrid;

//    private int currentIndex = 0;
    private int selectedSlot = -1;

    private int[] playerGuess = new int[4];

    private int[] secretCode = new int[4];

    private int attemptsLeft = 12;

    private int score = 0;

    private LinearLayout guessRow;

//    private ArrayList<ImageView> slots =
//            new ArrayList<>();
private ArrayList<TextView> slots =
        new ArrayList<>();

    private int codeLength = 4;

    private View cyanBtn;
    private View pinkBtn;
    private View brownBtn;
    private View grayBtn;

    private int colorCount = 6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerDifficulty = findViewById(R.id.spinnerDifficulty);
        txtAttempts = findViewById(R.id.txtAttempts);
        txtScore = findViewById(R.id.txtScore);
        btnCheck = findViewById(R.id.btnCheck);
        btnUndo = findViewById(R.id.btnUndo);
        btnRestart = findViewById(R.id.btnRestart);
        feedbackGrid = findViewById(R.id.feedbackGrid);
        guessRow = findViewById(R.id.guessRow);
        switchDuplicate = findViewById(R.id.switchDuplicate);

        cyanBtn = findViewById(R.id.cyanBtn);
        pinkBtn = findViewById(R.id.pinkBtn);
        brownBtn = findViewById(R.id.brownBtn);
        grayBtn = findViewById(R.id.grayBtn);

        txtScore.setText("Score: 0");

        String[] levels = {
                "Easy",
                "Medium",
                "Hard"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_dropdown_item,
                        levels);

        spinnerDifficulty.setAdapter(adapter);

        startNewGame();

        spinnerDifficulty.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            android.view.View view,
                            int position,
                            long id) {

                        startNewGame();
                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent) {
                    }
                });

        findViewById(R.id.redBtn)
                .setOnClickListener(v ->
                        addColor(RED));

        findViewById(R.id.blueBtn)
                .setOnClickListener(v ->
                        addColor(BLUE));

        findViewById(R.id.greenBtn)
                .setOnClickListener(v ->
                        addColor(GREEN));

        findViewById(R.id.yellowBtn)
                .setOnClickListener(v ->
                        addColor(YELLOW));

        findViewById(R.id.purpleBtn)
                .setOnClickListener(v ->
                        addColor(PURPLE));

        findViewById(R.id.orangeBtn)
                .setOnClickListener(v ->
                        addColor(ORANGE));

        findViewById(R.id.cyanBtn)
                .setOnClickListener(v ->
                        addColor(CYAN));

        findViewById(R.id.pinkBtn)
                .setOnClickListener(v ->
                        addColor(PINK));

        findViewById(R.id.brownBtn)
                .setOnClickListener(v ->
                        addColor(BROWN));

        findViewById(R.id.grayBtn)
                .setOnClickListener(v ->
                        addColor(GRAY));

        historyRecycler =
                findViewById(R.id.historyRecycler);

        historyList = new ArrayList<>();

        historyAdapter =
                new HistoryAdapter(historyList);

        historyRecycler.setLayoutManager(
                new LinearLayoutManager(this));

        historyRecycler.setAdapter(
                historyAdapter);

        startNewGame();
//        ImageView peg = new ImageView(this);
//
//        if(exactMatch){
//            peg.setBackgroundColor(Color.BLACK);
//        }
//        else{
//            peg.setBackgroundColor(Color.WHITE);
//        }

        if(savedInstanceState != null){

            score =
                    savedInstanceState
                            .getInt("score");

            attemptsLeft =
                    savedInstanceState
                            .getInt("attempts");

            txtScore.setText(
                    "Score: " + score);

            txtAttempts.setText(
                    "Attempts: "
                            + attemptsLeft);
        }


        btnUndo.setOnClickListener(v -> {

            if(selectedSlot  > 0){

//                selectedSlot --;

                slots.get(selectedSlot )
                        .setBackgroundResource(
                                R.drawable.peg_empty);

                playerGuess[selectedSlot ] = 0;
            }
        });

//        redBtn.setOnClickListener(v -> addColor(1));
//        blueBtn.setOnClickListener(v -> addColor(2));
//        greenBtn.setOnClickListener(v -> addColor(3));
//        yellowBtn.setOnClickListener(v -> addColor(4));
//        purpleBtn.setOnClickListener(v -> addColor(5));
//        orangeBtn.setOnClickListener(v -> addColor(6));
        cyanBtn.setOnClickListener(v -> {
                Toast.makeText(
                                this,
                                "Red Clicked",
                                Toast.LENGTH_SHORT)
                        .show();
                addColor(7);});
        pinkBtn.setOnClickListener(v -> addColor(8));
        brownBtn.setOnClickListener(v -> addColor(9));
        grayBtn.setOnClickListener(v -> addColor(10));

        Button btnRestart =
                findViewById(R.id.btnRestart);

        btnCheck.setOnClickListener(v ->
                checkGuess());

        btnUndo.setOnClickListener(v ->
                undoMove());

        btnRestart.setOnClickListener(v ->
                startNewGame());

        showFeedback(exactMatches, partialMatches);
    }

    private void showFeedback(
            int exactMatches,
            int partialMatches) {

        feedbackGrid.removeAllViews();

        // Black Pegs
        for(int i = 0; i < exactMatches; i++) {

//            ImageView peg = new ImageView(this);

            TextView peg = new TextView(this);

            peg.setGravity(Gravity.CENTER);

            peg.setTextSize(18);

            peg.setTextColor(Color.WHITE);

            peg.setBackgroundResource(
                    R.drawable.peg_circle);

            peg.setBackgroundResource(
                    R.drawable.feedback_black);

            GridLayout.LayoutParams params =
                    new GridLayout.LayoutParams();

            params.width = 25;
            params.height = 25;

            peg.setLayoutParams(params);

            feedbackGrid.addView(peg);
        }

        // White Pegs
        for(int i = 0; i < partialMatches; i++) {

//            ImageView peg = new ImageView(this);

            TextView peg = new TextView(this);

            peg.setGravity(Gravity.CENTER);

            peg.setTextSize(18);

            peg.setTextColor(Color.WHITE);

            peg.setBackgroundResource(
                    R.drawable.peg_circle);

            peg.setBackgroundResource(
                    R.drawable.feedback_white);

            GridLayout.LayoutParams params =
                    new GridLayout.LayoutParams();

            params.width = 25;
            params.height = 25;

            peg.setLayoutParams(params);

            feedbackGrid.addView(peg);
        }
    }

    private void createSlots() {

        guessRow.removeAllViews();
        TextView peg = new TextView(this);

        peg.setGravity(Gravity.CENTER);

        peg.setTextSize(18);

        peg.setTextColor(Color.WHITE);

        peg.setBackgroundResource(
                R.drawable.peg_circle);

        slots.clear();

        for(int i=0;i<codeLength;i++) {

//            ImageView peg =
//                    new ImageView(this);

            peg = new TextView(this);

            peg.setGravity(Gravity.CENTER);

            peg.setTextSize(18);

            peg.setTextColor(Color.WHITE);

            peg.setBackgroundResource(
                    R.drawable.peg_circle);

//            LinearLayout.LayoutParams params =
//                    new LinearLayout.LayoutParams(
//                            90,
//                            90);
            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            getResources()
                                    .getDimensionPixelSize(
                                            R.dimen.peg_size),

                            getResources()
                                    .getDimensionPixelSize(
                                            R.dimen.peg_size));

            params.setMargins(
                    5,5,5,5);

            peg.setLayoutParams(params);

            peg.setBackgroundResource(
                    R.drawable.peg_empty);

            final int index = i;

            peg.setClickable(true);

            peg.setOnClickListener(v -> {

                Toast.makeText(
                                MainActivity.this,
                                "Slot " + index,
                                Toast.LENGTH_SHORT)
                        .show();

                selectSlot(index);
                updateSlotViews();
            });

            peg.setOnLongClickListener(v -> {

                playerGuess[index] = 0;
//
//                ((ImageView) v).setBackgroundResource(
//                        R.drawable.peg_empty);
                ((TextView) v).setBackgroundResource(
                        R.drawable.peg_empty);

                return true;
            });

            guessRow.addView(peg);

            slots.add(peg);
        }

        playerGuess =
                new int[codeLength];

        secretCode =
                new int[codeLength];
    }

//    private void selectSlot(int index){
//
//        Log.d(
//                "MM",
//                "Selected Slot = "
//                        + index);
//
//        selectedSlot = index;
//
//        for(int i=0;i<slots.size();i++){
//
//            slots.get(i)
//                    .setBackgroundResource(
//                            R.drawable.peg_empty);
//        }
//
//        updateSlotViews();
//
//        slots.get(index)
//                .setBackgroundResource(
//                        R.drawable.selected_slot_border);
//    }

    private void selectSlot(int index){

        selectedSlot = index;

        updateSlotViews();
    }

    private void startNewGame() {

        String level =
                spinnerDifficulty
                        .getSelectedItem()
                        .toString();

        switch(level){

            case "Easy":

                codeLength = 4;
                colorCount = 6;
                attemptsLeft = 12;

                break;

            case "Medium":

                codeLength = 5;
                colorCount = 8;
                attemptsLeft = 10;

                break;

            default:

                codeLength = 6;
                colorCount = 10;
                attemptsLeft = 8;

                break;
        }

        createSlots();

        updateColorButtons();

        generateSecretCode();

        selectedSlot = 0;

        txtAttempts.setText(
                "Attempts: "
                        + attemptsLeft);

        clearHistory();

        feedbackGrid.removeAllViews();
    }

    private void generateSecretCode() {

        Random random =
                new Random();

        if(switchDuplicate.isChecked()){

            for(int i=0;i<codeLength;i++){

                secretCode[i] =
                        random.nextInt(
                                colorCount)+1;
            }
        }
        else{

            ArrayList<Integer> colors =
                    new ArrayList<>();

            for(int i=1;
                i<=colorCount;
                i++){

                colors.add(i);
            }

            Collections.shuffle(colors);

            for(int i=0;
                i<codeLength;
                i++){

                secretCode[i] =
                        colors.get(i);
            }
        }
    }

    //    Secret Code Reveal
    private String secretCodeToString(){

        StringBuilder sb =
                new StringBuilder();

        for(int value : secretCode){

            sb.append(value);
        }

        return sb.toString();
    }

    private void addColor(int color){

        Log.d(
                "MM",
                "Current Selected = "
                        + selectedSlot);

        if(selectedSlot == -1) {
            Toast.makeText(
                            this,
                            "Select Slot First",
                            Toast.LENGTH_SHORT)
                    .show();
            return;
        }


        playerGuess[selectedSlot] = color;

        updateSlotViews();
    }

    private void updateSlotViews(){


        for(int i=0;i<codeLength;i++){

            TextView peg = slots.get(i);

            if(playerGuess[i] == 0){


                peg.setText("");

                peg.setBackgroundResource(
                        R.drawable.peg_circle);
                peg.getBackground()
                        .setTint(Color.LTGRAY);
//                peg.setBackgroundColor(
//                        Color.LTGRAY);

//                slots.get(i).setText("");
//
//                slots.get(i)
//                        .setBackgroundTintList(
//                                ColorStateList.valueOf(
//                                        Color.LTGRAY));
            }
//            else{
//
//                setPegColor(
//                        slots.get(i),
//                        playerGuess[i]);
//            }

            else{

                peg.setText(
                        String.valueOf(
                                playerGuess[i]));

                switch(playerGuess[i]){

                    case 1:
                        peg.setBackgroundResource(
                                R.drawable.peg_circle);
                        peg.getBackground()
                                .setTint(Color.RED);
                        break;

                    case 2:
                        peg.setBackgroundResource(
                                R.drawable.peg_circle);
                        peg.getBackground()
                                .setTint(Color.BLUE);
                        break;

                    case 3:
                        peg.setBackgroundResource(
                                R.drawable.peg_circle);
                        peg.getBackground()
                                .setTint(Color.GREEN);
                        break;

                    case 4:
                        peg.setBackgroundResource(
                            R.drawable.peg_circle);
                        peg.getBackground()
                                .setTint(Color.YELLOW);

                        peg.setTextColor(
                                Color.BLACK);
                        break;

                    case 5:
                        peg.setBackgroundResource(
                                R.drawable.peg_circle);
                        peg.getBackground()
                                .setTint(Color.MAGENTA);
                        break;

                    case 6:
                        peg.setBackgroundResource(
                                R.drawable.peg_circle);
                        peg.getBackground()
                                .setTint(0xFFFF9800);
                        break;
                }
            }

//        if(selectedSlot >= 0){
//
//            slots.get(selectedSlot)
//                    .setScaleX(1.2f);
//
//            slots.get(selectedSlot)
//                    .setScaleY(1.2f);
//        }


//            switch(playerGuess[i]){
//
//                case RED:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_red);
//
//                    break;
//
//                case BLUE:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_blue);
//
//                    break;
//
//                case GREEN:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_green);
//
//                    break;
//
//                case YELLOW:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_yellow);
//
//                    break;
//
//                case PURPLE:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_purple);
//
//                    break;
//
//                case ORANGE:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_orange);
//
//                    break;
//
//                case CYAN:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_cyan);
//
//                    break;
//
//                case PINK:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_pink);
//
//                    break;
//
//                case BROWN:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_brown);
//
//                    break;
//
//                case GRAY:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_gray);
//
//                    break;
//
//                default:
//
//                    slots.get(i)
//                            .setBackgroundResource(
//                                    R.drawable.peg_empty);
//            }
        }

        //remove select cell border
        for(int i=0;i<slots.size();i++){

            slots.get(i)
                    .setForeground(null);
        }


        if(selectedSlot >= 0){

            slots.get(selectedSlot)
                    .setForeground(
                            getDrawable(
                                    R.drawable.selected_slot_border));
        }

//        for(int i = 0; i < slots.size(); i++){
//
//            if(i == selectedSlot){
//
//                slots.get(i).setScaleX(1.3f);
//                slots.get(i).setScaleY(1.3f);
//
//            } else {
//
//                slots.get(i).setScaleX(1f);
//                slots.get(i).setScaleY(1f);
//            }
//        }
    }

    private void setPegColor(
            TextView peg,
            int colorNumber){

        peg.setText(
                String.valueOf(colorNumber));

        switch(colorNumber){

            case 1:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                Color.RED));
                break;

            case 2:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                Color.BLUE));
                break;

            case 3:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                Color.GREEN));
                break;

            case 4:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                Color.YELLOW));

                peg.setTextColor(
                        Color.BLACK);
                break;

            case 5:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                Color.MAGENTA));
                break;

            case 6:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                0xFFFF9800));
                break;

            case 7:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                Color.CYAN));
                break;

            case 8:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                0xFFE91E63));
                break;

            case 9:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                0xFF795548));
                break;

            case 10:
                peg.setBackgroundTintList(
                        ColorStateList.valueOf(
                                Color.GRAY));
                break;
        }
    }

    private void undoMove(){

        if(selectedSlot <= 0)
            return;

//        currentIndex--;

        playerGuess[selectedSlot] = 0;

        slots.get(selectedSlot )
                .setBackgroundResource(
                        R.drawable.peg_empty);

        //Undo Animation
        slots.get(selectedSlot)
                .animate()
                .alpha(0f)
                .setDuration(150)
                .withEndAction(() -> {

                    slots.get(selectedSlot)
                            .setBackgroundResource(
                                    R.drawable.peg_empty);

                    slots.get(selectedSlot)
                            .setAlpha(1f);
                });
    }

    private void checkGuess(){

        for(int color : playerGuess){

            if(color == 0){

                Toast.makeText(
                                this,
                                "Fill all slots",
                                Toast.LENGTH_SHORT)
                        .show();

                return;
            }
        }

        int exactMatches = 0;
        int partialMatches = 0;

        boolean[] secretUsed =
                new boolean[codeLength];

        boolean[] guessUsed =
                new boolean[codeLength];

        for(int i=0;i<codeLength;i++){

            if(playerGuess[i]
                    == secretCode[i]){

                exactMatches++;

                secretUsed[i] = true;

                guessUsed[i] = true;
            }
        }

        for(int i=0;i<codeLength;i++){

            if(guessUsed[i])
                continue;

            for(int j=0;j<codeLength;j++){

                if(secretUsed[j])
                    continue;

                if(playerGuess[i]
                        == secretCode[j]){

                    partialMatches++;

                    secretUsed[j] = true;

                    break;
                }
            }
        }

        showFeedback(
                exactMatches,
                partialMatches);


        addHistory(
                playerGuess.clone(),
                exactMatches,
                partialMatches);

        attemptsLeft--;

        txtAttempts.setText(
                "Attempts: "
                        + attemptsLeft);

        if(exactMatches == codeLength){

            switch(codeLength){

                case 4:
                    score += 100;
                    break;

                case 5:
                    score += 200;
                    break;

                case 6:
                    score += 300;
                    break;
            }
            //Fast win bonus:
            score += attemptsLeft * 10;
            showWinDialog();
            return;
        }

        if(attemptsLeft <= 0){
            showLoseDialog();
            return;
        }

        selectedSlot = -1;

        clearGuess();
    }

    private void clearGuess(){

        for(int i=0;i<codeLength;i++){

            playerGuess[i] = 0;
        }

        selectedSlot = -1;

        updateSlotViews();

    }

    private void addHistory(
            int[] guessColors,
            int exactMatches,
            int partialMatches){

        historyList.add(
                new HistoryItem(
                        guessColors,
                        exactMatches,
                        partialMatches));

        historyAdapter.notifyItemInserted(
                historyList.size()-1);
    }

    private void clearHistory() {

        if(historyList != null){

            historyList.clear();
        }

        if(historyAdapter != null){

            historyAdapter.notifyDataSetChanged();
        }
    }

    private int getPegDrawable(
            int colorId){

        switch(colorId){

            case 1:
                return R.drawable.peg_red;

            case 2:
                return R.drawable.peg_blue;

            case 3:
                return R.drawable.peg_green;

            case 4:
                return R.drawable.peg_yellow;

            case 5:
                return R.drawable.peg_purple;

            case 6:
                return R.drawable.peg_orange;

            case 7:
                return R.drawable.peg_cyan;

            case 8:
                return R.drawable.peg_pink;

            case 9:
                return R.drawable.peg_brown;

            case 10:
                return R.drawable.peg_gray;
        }

        return R.drawable.peg_empty;
    }

    private void updateColorButtons() {

        cyanBtn.setVisibility(View.GONE);
        pinkBtn.setVisibility(View.GONE);
        brownBtn.setVisibility(View.GONE);
        grayBtn.setVisibility(View.GONE);

        if(colorCount >= 8){

            cyanBtn.setVisibility(View.VISIBLE);
            pinkBtn.setVisibility(View.VISIBLE);
        }

        if(colorCount >= 10){

            brownBtn.setVisibility(View.VISIBLE);
            grayBtn.setVisibility(View.VISIBLE);
        }
    }

////    private void showFeedback(
////            int exactMatches,
////            int partialMatches){
////
////        feedbackGrid.removeAllViews();
//    public void onBindViewHolder(
//                RecyclerView.ViewHolder holder,
//        int position) {
//
//            HistoryItem item =
//                    historyList.get(position);
//
//            holder.guessContainer.removeAllViews();
//
//            holder.feedbackContainer
//                    .removeAllViews();
//
//            int[] colors =
//                    item.getGuessColors();
//
//        // Guess Pegs
//
//        for(int color : colors){
//
//            ImageView peg =
//                    new ImageView(
//                            holder.itemView
//                                    .getContext());
//
//            LinearLayout.LayoutParams params =
//                    new LinearLayout.LayoutParams(
//                            50,
//                            50);
//
//            params.setMargins(
//                    4,4,4,4);
//
//            peg.setLayoutParams(params);
//
//            peg.setBackgroundResource(
//                    getPegDrawable(color));
//
//            holder.guessContainer
//                    .addView(peg);
//        }
//
//        //black feedback
//         for(int i=0;
//                i<item.getExactMatches();
//                i++){
//
//                ImageView peg =
//                        new ImageView(
//                                holder.itemView
//                                        .getContext());
//
//                peg.setBackgroundResource(
//                        R.drawable.feedback_black);
//
//                GridLayout.LayoutParams params =
//                        new GridLayout.LayoutParams();
//
//                params.width = 18;
//                params.height = 18;
//
//                peg.setLayoutParams(params);
//
//                holder.feedbackContainer
//                        .addView(peg);
//            }
////        for(int i=0;i<exactMatches;i++){
////
////            ImageView peg =
////                    new ImageView(this);
////
////            peg.setBackgroundResource(
////                    R.drawable.feedback_black);
////
////            GridLayout.LayoutParams params =
////                    new GridLayout.LayoutParams();
////
////            params.width = 25;
////            params.height = 25;
////
////            peg.setLayoutParams(params);
////
////            feedbackGrid.addView(peg);
////
////            // Feedback Peg Animation
////            peg.setScaleX(0f);
////            peg.setScaleY(0f);
////
////            peg.animate()
////                    .scaleX(1f)
////                    .scaleY(1f)
////                    .setDuration(250);
////        }
//
//        //white feedback
//        for(int i=0;
//            i<item.getPartialMatches();
//            i++){
//
//            ImageView peg =
//                    new ImageView(
//                            holder.itemView
//                                    .getContext());
//
//            peg.setBackgroundResource(
//                    R.drawable.feedback_white);
//
//            GridLayout.LayoutParams params =
//                    new GridLayout.LayoutParams();
//
//            params.width = 18;
//            params.height = 18;
//
//            peg.setLayoutParams(params);
//
//            holder.feedbackContainer
//                    .addView(peg);
//        }
////        for(int i=0;i<partialMatches;i++){
////
////            ImageView peg =
////                    new ImageView(this);
////
////            peg.setBackgroundResource(
////                    R.drawable.feedback_white);
////
////            GridLayout.LayoutParams params =
////                    new GridLayout.LayoutParams();
////
////            params.width = 25;
////            params.height = 25;
////
////            peg.setLayoutParams(params);
////
////            feedbackGrid.addView(peg);
////
////            // Feedback Peg Animation
////            peg.setScaleX(0f);
////            peg.setScaleY(0f);
////
////            peg.animate()
////                    .scaleX(1f)
////                    .scaleY(1f)
////                    .setDuration(250);
////        }
//
//
//    }

    private String guessToString(){

        StringBuilder sb =
                new StringBuilder();

        for(int value : playerGuess){

            sb.append(value);
        }

        return sb.toString();
    }

    private void showWinDialog(){

        new AlertDialog.Builder(this)

                .setTitle("You Win!")

                .setMessage(
                        "Secret Code: "
                                + secretCodeToString())

                .setPositiveButton(
                        "New Game",
                        (d,w)->startNewGame())

                .show();
    }

    private void showLoseDialog(){

        new AlertDialog.Builder(this)
                .setTitle("Game Over")
                .setMessage(
                        "Secret Code\n\n"
                                + secretCodeToString())
                .setCancelable(false)
                .setPositiveButton(
                        "New Game",
                        (d,w)->startNewGame())
                .show();
    }

    @Override
    protected void onSaveInstanceState(
            Bundle outState) {

        super.onSaveInstanceState(
                outState);

        outState.putInt(
                "score",
                score);

        outState.putInt(
                "attempts",
                attemptsLeft);
    }

    //Secret Code Preview Dialog, Debug mode के लिए:
    private void showSecretCode() {

        new AlertDialog.Builder(this)

                .setTitle("Secret")

                .setMessage(
                        secretCodeToString())

                .show();
    }
}